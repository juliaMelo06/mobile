import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonPress = (value) => {
    setInput(input + value);
  };

  const calculateResult = () => {
    try {
      setResult(eval(input).toString());
    } catch (error) {
      setResult('Error');
    }
  };

  const clearInput = () => {
    setInput('');
    setResult('');
  };

  const renderButton = (title, onPress, style) => (
    <TouchableOpacity style={[styles.button, style]} onPress={onPress}>
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.display}>
        <Text style={styles.result}>{result}</Text>
        <Text style={styles.input}>{input}</Text>
      </View>
      <View style={styles.buttonContainer}>
        {renderButton('1', () => handleButtonPress('1'))}
        {renderButton('2', () => handleButtonPress('2'))}
        {renderButton('3', () => handleButtonPress('3'))}
        {renderButton('+', () => handleButtonPress('+'), styles.operatorButton)}
      </View>
      <View style={styles.buttonContainer}>
        {renderButton('4', () => handleButtonPress('4'))}
        {renderButton('5', () => handleButtonPress('5'))}
        {renderButton('6', () => handleButtonPress('6'))}
        {renderButton('-', () => handleButtonPress('-'), styles.operatorButton)}
      </View>
      <View style={styles.buttonContainer}>
        {renderButton('7', () => handleButtonPress('7'))}
        {renderButton('8', () => handleButtonPress('8'))}
        {renderButton('9', () => handleButtonPress('9'))}
        {renderButton('*', () => handleButtonPress('*'), styles.operatorButton)}
      </View>
      <View style={styles.buttonContainer}>
        {renderButton('C', clearInput, styles.clearButton)}
        {renderButton('0', () => handleButtonPress('0'))}
        {renderButton('=', calculateResult, styles.equalButton)}
        {renderButton('/', () => handleButtonPress('/'), styles.operatorButton)}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 20,
    backgroundColor: '#FFB6C1',
  },
  display: {
    backgroundColor: '#FFFFFF', // Cor do visor
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    alignItems: 'flex-end',
    elevation: 5, // Sombra para dar destaque
  },
  result: {
    fontSize: 40,
    textAlign: 'right',
    color: '#000000', // Cor do texto do resultado
  },
  input: {
    fontSize: 30,
    textAlign: 'right',
    color: '#000000', // Cor do texto da entrada
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    flex: 1,
    margin: 5,
    backgroundColor: '#FFF0F5',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    height: 70,
  },
  buttonText: {
    fontSize: 24,
    color: '#282c34',
  },
  operatorButton: {
    backgroundColor: '#E0FFFF',
  },
  clearButton: {
    backgroundColor: '#FFFFE0',
  },
  equalButton: {
    backgroundColor: '#F0FFF0',
  },
});

export default App;