import React from 'react';
import { StyleSheet, Text, View, Image, Linking, TouchableOpacity, ScrollView } from 'react-native';

export default function App() {
  const openLink = (url) => {
    Linking.openURL(url);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>
        <Image
          style={styles.profileImage}
          source={{
            uri:'https://preview.redd.it/2szaq3h6dj7d1.jpeg?auto=webp&s=8a7da6c77efaa96aa99df26802c06218138ce0e3',
          }}
        />
        <Text style={styles.name}>Júlia Melo</Text>
        <Text style={styles.role}>Desenvolvedora Front-end</Text>
        <Text style={styles.description}>
          Apaixonada por design, código limpo e boas experiências de usuário. Entusiasta de React e criatividade digital.
        </Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={() => openLink('https://github.com/juliaMelo06')}>
            <Text style={styles.buttonText}>GitHub</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => openLink('https://linkedin.com')}>
            <Text style={styles.buttonText}>LinkedIn</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => openLink('mailto:julia.melo.eva@gmail.com')}>
            <Text style={styles.buttonText}>Email</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFF0F5', 
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 6,
    width: '100%',
    maxWidth: 380,
  },
  profileImage: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 3,
    borderColor: '#fff0f5',
    marginBottom: 15,
  },
  name: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  role: {
    fontSize: 16,
    color: '#FF69B4',
    marginBottom: 12,
    fontStyle: 'italic',
  },
  description: {
    fontSize: 15,
    color: '#555',
    textAlign: 'center',
    marginBottom: 25,
    paddingHorizontal: 10,
    lineHeight: 22,
  },
  buttonContainer: {
    width: '100%',
  },
  button: {
    backgroundColor: '#FF69B4',
    paddingVertical: 14,
    marginBottom: 12,
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#FFB6C1',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
