import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Clipboard,
  Alert,
  ScrollView,
  SafeAreaView,
  Platform
} from 'react-native';

export default function App() {
  const [easy, setEasy] = useState('');
  const [medium, setMedium] = useState('');
  const [hard, setHard] = useState('');

  const generatePasswords = () => {
    const easyChars = 'abcdefghijklmnopqrstuvwxyz';
    const mediumChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const hardChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*';

    const createPassword = (length, chars) => {
      let pass = '';
      for (let i = 0; i < length; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return pass;
    };

    setEasy(createPassword(8, easyChars));
    setMedium(createPassword(10, mediumChars));
    setHard(createPassword(12, hardChars));
  };

  const copyPassword = (text) => {
    Clipboard.setString(text);
    Alert.alert('Senha copiada!', `"${text}" foi copiada para a área de transferência.`);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Gerador de Senhas 🌸</Text>

        <TouchableOpacity style={styles.button} onPress={generatePasswords}>
          <Text style={styles.buttonText}>Gerar Senhas</Text>
        </TouchableOpacity>

        <PasswordCard level="Fácil" password={easy} onCopy={() => copyPassword(easy)} />
        <PasswordCard level="Média" password={medium} onCopy={() => copyPassword(medium)} />
        <PasswordCard level="Difícil" password={hard} onCopy={() => copyPassword(hard)} />
      </ScrollView>
    </SafeAreaView>
  );
}

const PasswordCard = ({ level, password, onCopy }) => (
  <View style={styles.passwordBox}>
    <Text style={styles.level}>{level}</Text>
    <Text style={styles.password}>{password || 'Clique em "Gerar Senhas"'}</Text>
    {password ? (
      <TouchableOpacity style={styles.copyButton} onPress={onCopy}>
        <Text style={styles.copyText}>Copiar</Text>
      </TouchableOpacity>
    ) : null}
  </View>
);

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#fff0f5',
  },
  container: {
    alignItems: 'center',
    padding: 20,
    paddingBottom: 60,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#cc3366',
    marginBottom: 20,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#ff69b4',
    paddingVertical: 14,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginBottom: 30,
    width: '80%',
    maxWidth: 300,
    elevation: 3,
    ...Platform.select({
      ios: {
        shadowColor: '#ff69b4',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
      },
    }),
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  passwordBox: {
    backgroundColor: '#fff',
    width: '90%',
    maxWidth: 400,
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    elevation: 4,
    ...Platform.select({
      ios: {
        shadowColor: '#ccc',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.2,
        shadowRadius: 6,
      },
    }),
  },
  level: {
    fontSize: 16,
    fontWeight: '700',
    color: '#cc3366',
    marginBottom: 8,
  },
  password: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#444',
    marginBottom: 12,
    flexWrap: 'wrap',
  },
  copyButton: {
    backgroundColor: '#cc3366',
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  copyText: {
    color: '#fff',
    fontWeight: '500',
  },
});
